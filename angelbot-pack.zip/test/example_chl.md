
## 1.0.1 (2019.11.10)

BUG FIXES:

* Donec accumsan ante vitae purus interdum, non consectetur nibh accumsan.[PR#12345]
* Praesent scelerisque turpis in rhoncus tincidunt.
* Ut pretium ante vel justo facilisis, a placerat metus mollis.
* Curabitur ut sapien ac nulla vestibulum eleifend et et augue.

BREAKING CHANGES:

* Aenean volutpat nibh at enim ultrices, finibus pharetra sapien fermentum.
* Sed sit amet metus vel nisl pharetra luctus quis in ligula.[PR#1234567889]
* Aenean sollicitudin urna vitae libero hendrerit malesuada.
* In nec ipsum posuere, interdum nisi blandit, pretium leo.

FEATURES:

* Quisque nec purus elementum nunc feugiat ultricies sit amet eget diam.
* Aliquam non urna eu odio pharetra pretium eu sit amet nulla.[PR#12345, PR123455]
* Integer molestie mi sit amet felis fermentum, eget lobortis metus congue.


IMPROVEMENTS:

* Sed consectetur nisi at magna venenatis interdum id eleifend lectus.
* Cras at libero eget enim efficitur fringilla.
* Aliquam elementum erat eu semper bibendum.
* In nec mauris mattis, lacinia enim nec, egestas erat.
