'use strict';
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const AWS = require('aws-sdk');
const lambda = new AWS.Lambda();

// TODO implement request verification with https://api.slack.com/docs/verifying-requests-from-slack
// and https://github.com/slackapi/template-channel-naming/blob/master/src/verifySignature.js
// TODO implement x-api-key for non slack endpoints like changelog posting

// Parse incoming requests data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Prevent timeout with status 200 and invoke angelbot to handle request
app.post('/api/v1/changelog', async (req, res) => {
  // invokeAngelbot(req.body.response_url, req.body.text);
  res.status(200).send(
    'Let me look for you ' + req.body.user_name
  );
});

const invokeAngelbot = (delayedURL, text) => {
  const payload = { url: delayedURL, command: text };
  const params = {
    FunctionName: 'angelbot',
    InvocationType: 'Event',
    Payload: payload
  };

  return new Promise((resolve, reject) => {
    lambda.invoke(params, (err, data) => {
      if (err) {
        console.log(err, err.stack);
        reject(err);
      } else {
        console.log(data);
        resolve(data);
      }
    });
  });
};

module.exports = app;
